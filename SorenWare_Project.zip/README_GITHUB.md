# SorenWare — GitHub Actions Build

Versi ini sudah disiapkan untuk build APK melalui GitHub Actions.

## Cara pakai dari HP

1. Buat repository GitHub baru.
2. Upload seluruh isi ZIP ini ke repository (bukan ZIP-nya sebagai satu file).
3. Pastikan folder `.github/workflows/build-apk.yml` ikut ter-upload.
4. Buka tab **Actions**.
5. Pilih **Build SorenWare APK**.
6. Tekan **Run workflow** untuk build manual, atau push ke `main`/`master`.
7. Setelah selesai, buka workflow run tersebut.
8. Di bagian **Artifacts**, download `SorenWare-debug-apk`.

GitHub Actions akan menjalankan Gradle di runner GitHub dan menyimpan APK hasil build sebagai artifact.

## Catatan

- Ini menghasilkan **debug APK**, cocok untuk testing.
- Tidak membutuhkan AndroidIDE untuk proses build di GitHub.
- Fitur SorenWare tetap non-root dan tidak mengubah memory/aiming game.

package com.sorenware.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Display
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var deviceText: TextView
    private lateinit var thermalText: TextView
    private lateinit var networkText: TextView
    private lateinit var touchText: TextView
    private lateinit var statusText: TextView

    private var touchCount = 0
    private var lastTouchMs = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        deviceText = findViewById(R.id.deviceText)
        thermalText = findViewById(R.id.thermalText)
        networkText = findViewById(R.id.networkText)
        touchText = findViewById(R.id.touchText)
        statusText = findViewById(R.id.statusText)

        findViewById<Button>(R.id.performanceButton).setOnClickListener {
            applyPerformanceProfile()
        }
        findViewById<Button>(R.id.balancedButton).setOnClickListener {
            applyBalancedProfile()
        }
        findViewById<Button>(R.id.displayButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }

        updateAll()
    }

    override fun onResume() {
        super.onResume()
        updateAll()
    }

    private fun applyPerformanceProfile() {
        statusText.text = "PERFORMANCE READY"
        statusText.setTextColor(getColor(R.color.sw_accent))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        updateAll()
    }

    private fun applyBalancedProfile() {
        statusText.text = "BALANCED READY"
        statusText.setTextColor(getColor(R.color.sw_text))
        updateAll()
    }

    private fun updateAll() {
        val refresh = getRefreshRate()
        deviceText.text = buildString {
            append("DEVICE\n")
            append("${Build.MANUFACTURER} ${Build.MODEL}\n")
            append("Android ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}\n")
            append("Refresh rate: ${String.format("%.0f", refresh)} Hz")
        }

        thermalText.text = "THERMAL\n${thermalState()}"
        networkText.text = "NETWORK\n${networkState()}"
        touchText.text = "INPUT CHECK\nTouch events: $touchCount\nStatus: READY"
    }

    private fun getRefreshRate(): Float {
        return if (Build.VERSION.SDK_INT >= 30) {
            display?.refreshRate ?: 60f
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.refreshRate
        }
    }

    private fun thermalState(): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            return when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "NORMAL"
                PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
                PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
                PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
                PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"
                else -> "UNKNOWN"
            }
        }
        return "UNAVAILABLE"
    }

    private fun networkState(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "OFFLINE"
        val caps = cm.getNetworkCapabilities(network) ?: return "UNKNOWN"

        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi CONNECTED"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MOBILE DATA CONNECTED"
            else -> "CONNECTED"
        }
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            touchCount++
            lastTouchMs = System.currentTimeMillis()
            touchText?.text = "INPUT CHECK\nTouch events: $touchCount\nStatus: RESPONSIVE"
        }
        return super.dispatchTouchEvent(event)
    }
}

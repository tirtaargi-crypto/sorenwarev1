# SorenWare v1

Android game-performance companion for phones.

## Fokus
- Performance profile UI
- Balanced profile
- Thermal status monitoring
- Refresh-rate detection
- Network state monitoring
- Touch responsiveness check
- Quick links to Display/Battery settings
- Lightweight and non-root

## Batasan
Android does not give a normal third-party APK permission to directly overclock another app's CPU/GPU, change its touch sampling rate, read its true FPS, or alter its aiming logic.

SorenWare therefore does not include auto-aim, target locking, memory injection, anti-cheat bypass, or game modification.

## Build on AndroidIDE
1. Extract this ZIP.
2. Open the extracted folder as a Gradle Android project.
3. Let AndroidIDE sync/download Gradle and dependencies.
4. Build APK.
5. Install the generated APK.

Compile SDK: 35
Minimum SDK: 31
Target SDK: 35
